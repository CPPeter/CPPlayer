//
//  ViewController.m
//  CPPlayer
//
//  Created by  on 16/3/21.
//  Copyright © 2016年 . All rights reserved.
//

#import "ViewController.h"
#import "CPPlayer.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    NSURL *url2 = [NSURL URLWithString:@"http://zyvideo1.oss-cn-qingdao.aliyuncs.com/zyvd/7c/de/04ec95f4fd42d9d01f63b9683ad0"];
    [[CPPlayer sharePlayer] playerWithUrl:url2 toShowView:self.view];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
