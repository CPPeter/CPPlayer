//
//  CPVideoRequestTask.h
//  CPPlayer
//
//  Created by  on 16/3/21.
//  Copyright © 2016年 . All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
@class CPVideoRequestTask;

@protocol CPVideoRequestTaskDelegate <NSObject>

- (void)task:(CPVideoRequestTask *)task didReceiveVideoLength:(NSUInteger)ideoLength mimeType:(NSString *)mimeType;
- (void)didReceiveVideoDataWithTask:(CPVideoRequestTask *)task;
- (void)didFinishLoadingWithTask:(CPVideoRequestTask *)task;
- (void)didFailLoadingWithTask:(CPVideoRequestTask *)task WithError:(NSInteger )errorCode;

@end

@interface CPVideoRequestTask : NSObject
@property (nonatomic, copy) NSString                             *movePath;
@property (nonatomic, copy) NSString                             *tempPath;
@property (nonatomic, strong) NSURL                      *url;
@property (nonatomic                 ) NSUInteger                 offset;//下载数据的起始位置

@property (nonatomic                  ) NSUInteger                 videoLength;
@property (nonatomic                  ) NSUInteger                 downLoadingOffset;//下载的数据长度
@property (nonatomic, copy) NSString                   * mimeType;

@property (nonatomic, assign)           BOOL                       isFinishLoad;
@property (nonatomic, weak) id<CPVideoRequestTaskDelegate> delegate;
-(void)setUrl:(NSURL *)url offset:(NSInteger )offset;
@end
