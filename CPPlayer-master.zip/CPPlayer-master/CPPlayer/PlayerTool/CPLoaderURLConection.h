//
//  CPLoaderURLConection.h
//  CPPlayer
//
//  Created by  on 16/3/21.
//  Copyright © 2016年 . All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "CPVideoRequestTask.h"

@protocol CPLoaderURLConectionDelegate <NSObject>
- (void)didFinishLoadingWithTask:(CPVideoRequestTask *)task;
- (void)didFailLoadingWithTask:(CPVideoRequestTask *)task WithError:(NSInteger )errorCode;


@end

@interface CPLoaderURLConection : NSObject<AVAssetResourceLoaderDelegate>

@property (nonatomic,weak)id<CPLoaderURLConectionDelegate> delegate;
@property (nonatomic,strong) CPVideoRequestTask           *task;
@property (nonatomic,copy) NSString                       *videoPath;
@property (nonatomic,copy) NSString                       *tempPath;

-(NSURL *)getSchemeViderURL:(NSURL *)url;
@end
