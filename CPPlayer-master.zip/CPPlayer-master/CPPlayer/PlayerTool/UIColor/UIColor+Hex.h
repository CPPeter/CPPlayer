//
//  UIColor+Hex.h
//  TBPlayer
//
//  Created by  on 16/2/7.
//  Copyright © 2016年 SF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (Hex)
+(UIColor*)colorWithHex:(NSInteger)hexValue alpha:(CGFloat)alphaValue;
@end
