//
//  CPPlayer.h
//  CPPlayer
//
//  Created by  on 16/3/21.
//  Copyright © 2016年 . All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface CPPlayer : UIView
+(instancetype)sharePlayer;

-(void)playerWithUrl:(NSURL *)url toShowView:(UIView *)showView;
@end
