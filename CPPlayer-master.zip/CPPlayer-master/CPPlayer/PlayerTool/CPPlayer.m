//
//  CPPlayer.m
//  CPPlayer
//
//  Created by  on 16/3/21.
//  Copyright © 2016年 . All rights reserved.
// 播放界面

#import "CPPlayer.h"
#import "UIColor+Hex.h"
#import "CPLoaderURLConection.h"
#import "MBProgressHUD.h"

#define kScreenHeight ([UIScreen mainScreen].bounds.size.height)
#define kScreenWidth ([UIScreen mainScreen].bounds.size.width)
#define IOS_VERSION ([[[UIDevice currentDevice] systemVersion] floatValue])
typedef enum : NSUInteger {
    CPPlayerStatusBuffering = 1,
    CPPlayerStatusPlaying   = 2,
    CPPlayerStatusStop      = 3,
    CPPlayerStatePause      = 4
} CPPlayerStatus;

@class CPPlayer;
@interface CPPlayer ()<CPLoaderURLConectionDelegate>{
    
}
@property (nonatomic,strong)AVURLAsset            *videoAsset;
@property (nonatomic,strong)AVPlayerItem          *currentPlayerItem;
@property (nonatomic,strong)AVPlayer              *player;
@property (nonatomic,strong)AVPlayerLayer         *playerLayer;
@property (nonatomic,assign)CPPlayerStatus         status;
@property (nonatomic,assign)BOOL                   isUserPause;
@property (nonatomic,assign)BOOL                   isLocalVideo;
@property (nonatomic,strong)CPLoaderURLConection  *resouerLoader;
@property (nonatomic,strong)UIView                *navView;
@property (nonatomic,assign)CGFloat                loadedProgress;
@property (nonatomic,assign)BOOL                   isFinishLoad;//是否下载完成
/**
 *暂停按钮
 */
@property (nonatomic,strong)UIButton        *pauseBtn;

/**
 *当前时间
 */
@property (nonatomic,strong)UILabel         *currentTimeLabel;
/**
 *总时间
 */
@property (nonatomic,strong)UILabel          *totolTimeLabel;
/**
 *缓冲进度条
 */
@property (nonatomic,strong)UIProgressView   *videoProgressView;
/**
 *滑竿
 */
@property (nonatomic,strong)UISlider         *playSlider;
/**
 *重播按钮
 */
@property (nonatomic,strong)UIButton         *rerunBtn;
/**
 *
 */
@property (nonatomic,assign)CGFloat current;
/**
 *视频总时间
 */
@property (nonatomic,assign)CGFloat duration;
@end


static CPPlayer *_sharePlayer;
@implementation CPPlayer


+(instancetype)sharePlayer{
    if (!_sharePlayer) {
        _sharePlayer = [[CPPlayer alloc]init];
    }
    return _sharePlayer;
    
}
-(void)playerWithUrl:(NSURL *)url toShowView:(UIView *)showView{
    NSString *urlStr = url.absoluteString;
    NSArray *urlStrs = [urlStr componentsSeparatedByString:@"/"];
    NSURL *fileURl = nil;
    NSString *path = nil;
    if (urlStrs.count > 0) {
      NSString *fileUrlStr = [NSString stringWithFormat:@"%@.mp4",urlStrs.lastObject];
        NSString *document = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).lastObject;
        path =  [document stringByAppendingPathComponent:fileUrlStr];
        if ([[NSFileManager defaultManager] fileExistsAtPath:path]) {
           fileURl = [NSURL fileURLWithPath:path];
        }
    }
    if (IOS_VERSION < 7.0 || ![url.absoluteString hasPrefix:@"http"] || fileURl) {
        self.videoAsset = [AVURLAsset URLAssetWithURL:fileURl?fileURl:url options:nil];
        _isLocalVideo = YES;
    }else
    {
        self.resouerLoader = [[CPLoaderURLConection alloc]init];
        self.resouerLoader.delegate = self;
        NSURL *playUrl = [self.resouerLoader getSchemeViderURL:url];
        self.resouerLoader.videoPath = path;
        self.videoAsset = [AVURLAsset URLAssetWithURL:playUrl options:nil];
        [_videoAsset.resourceLoader setDelegate:_resouerLoader queue:dispatch_get_main_queue()];
        self.isLocalVideo = NO;
    }
    self.currentPlayerItem          = [AVPlayerItem playerItemWithAsset:self.videoAsset];
    if (!self.player) {
        self.player = [AVPlayer playerWithPlayerItem:self.currentPlayerItem];
    }else{
        [self.player replaceCurrentItemWithPlayerItem:self.currentPlayerItem];
    }
    self.playerLayer = [AVPlayerLayer playerLayerWithPlayer:self.player];
    self.playerLayer.frame = CGRectMake(0, 64, showView.bounds.size.width, showView.bounds.size.height-44);
    
    [self.currentPlayerItem addObserver:self forKeyPath:@"status" options:NSKeyValueObservingOptionNew context:nil];
    [self.currentPlayerItem addObserver:self forKeyPath:@"loadedTimeRanges" options:NSKeyValueObservingOptionNew context:nil];
    [self.currentPlayerItem addObserver:self forKeyPath:@"playbackBufferEmpty" options:NSKeyValueObservingOptionNew context:nil];
    [self.currentPlayerItem addObserver:self forKeyPath:@"playbackLikelyToKeepUp" options:NSKeyValueObservingOptionNew context:nil];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(appDidEnterBackground:) name:UIApplicationWillResignActiveNotification object:nil];//进入后台
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(appDidEnterPlayGround:) name:UIApplicationDidBecomeActiveNotification object:nil];//进入前台
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(playerItemPlayToEnd:) name:AVPlayerItemDidPlayToEndTimeNotification object:self.currentPlayerItem];//播放完成
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(playerItemPlaybackStalled:) name:AVPlayerItemPlaybackStalledNotification object:self.currentPlayerItem];//播放暂停
    //本地文件不设置CPPlayerStateBuffering状态
    if (fileURl) {
        self.status = CPPlayerStatusPlaying;
    }else
    {
        self.status = CPPlayerStatusBuffering;
    }
    [self creatUI:showView];
    [showView.layer addSublayer:self.playerLayer];
}
-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context{
    AVPlayerItem *playerItem = (AVPlayerItem *)object;
//    NSLog(@"keyPath=%@",keyPath);
    if ([keyPath isEqualToString:@"status"]) {
        if ([playerItem status] == AVPlayerItemStatusReadyToPlay) {
            [self monitoringPlayback:playerItem];//给播放器添加定时器
        }else if ([playerItem status] == AVPlayerStatusFailed){
            [self stop];
        }
    }else if ([keyPath isEqualToString:@"loadedTimeRanges"]){//监听播放器的下载进度
        [self calculateDownloadProgress:(AVPlayerItem *)playerItem];
    }else if ([keyPath isEqualToString:@"playbackBufferEmpty"]){
        if (playerItem.isPlaybackBufferEmpty) {
            [MBProgressHUD showHUDAddedTo:self animated:YES];
            //当前缓存区为空
            self.status = CPPlayerStatusBuffering;
            [self bufferingSomeSecond];
        }
    }
}
-(void)bufferingSomeSecond{
    static BOOL isBuffering = NO;
    if (isBuffering) {
        return ;
    }
    isBuffering = YES;
    //需要暂停一小会之后在播放,否则网络状态不好的时候事件在走,声音播放不出来
    [self pause];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (self.isUserPause) {
            isBuffering = NO;
            return ;
        }
        [self play];
        //如果执行了play还是没有播放则说明还没有缓存好,则再次缓存一会
        isBuffering = NO;
        if (!self.currentPlayerItem.isPlaybackLikelyToKeepUp) {
            //如果播放不能跟上则再次促发缓存
            [self bufferingSomeSecond];
        }
    });
}
-(void)calculateDownloadProgress:(AVPlayerItem *)playerItem{
    NSArray *loadedTimeRanges = [playerItem loadedTimeRanges];
//    self.resouerLoader.task.
    AVURLAsset *urlAsset = (AVURLAsset *)playerItem.asset;
    CMTimeRange timeRange = [loadedTimeRanges.firstObject CMTimeRangeValue];
    float startSeconds = CMTimeGetSeconds(timeRange.start);
    float durationSeconds = CMTimeGetSeconds(timeRange.duration);
    NSTimeInterval timeInterval = startSeconds + durationSeconds;
    CMTime duration = playerItem.duration;
    CGFloat totalDuration = CMTimeGetSeconds(duration);
    self.loadedProgress = timeInterval / totalDuration;
//    NSLog(@"timeInterval=%f",timeInterval);
    [self.videoProgressView setProgress:self.loadedProgress animated:YES];
}
-(void)monitoringPlayback:(AVPlayerItem *)playerItem{
    self.duration = playerItem.duration.value / playerItem.duration.timescale;
    [self play];
    [self updateTotolTime:self.duration];
    [self setPlaySliderValue:self.duration];
    __weak typeof(self) weakSelf = self;
    [self.player addPeriodicTimeObserverForInterval:CMTimeMake(1, 1) queue:NULL usingBlock:^(CMTime time) {
        CGFloat currentTime = playerItem.currentTime.value/playerItem.currentTime.timescale;
        [weakSelf updateCurrentTime:currentTime];
        [weakSelf updateVideoSlider:currentTime];
        if (weakSelf.isUserPause == NO) {
            weakSelf.status = CPPlayerStatusPlaying;
        }
        if (weakSelf.current != currentTime) {
            weakSelf.current = currentTime;
            if (weakSelf.current > weakSelf.duration) {
                weakSelf.duration = weakSelf.current;
            }
        }
    }];
}
-(void)updateVideoSlider:(NSInteger)time{
    [self.playSlider setValue:time animated:YES];
}
-(void)updateCurrentTime:(NSInteger)time{
    long videoLenth = ceil(time);
    NSString *strtotol = nil;
    if (videoLenth < 3600) {
        strtotol =  [NSString stringWithFormat:@"%02li:%02li",lround(floor(videoLenth/60.f)),lround(floor(videoLenth/1.f))%60];
    } else {
        strtotol =  [NSString stringWithFormat:@"%02li:%02li:%02li",lround(floor(videoLenth/3600.f)),lround(floor(videoLenth%3600)/60.f),lround(floor(videoLenth/1.f))%60];
    }
    
    self.currentTimeLabel.text = strtotol;
    [self.playSlider setValue:time animated:YES];
}
-(void)setPlaySliderValue:(NSInteger)time{
    self.playSlider.minimumValue = 0.0;
    self.playSlider.maximumValue = self.duration;
}
-(void)updateTotolTime:(NSInteger)time{
    long videoLenth = ceil(time);
    NSString *strtotol = nil;
    if (videoLenth < 3600) {
        strtotol = [NSString stringWithFormat:@"%02li:%02li",lround(floor(videoLenth/60.)),lround(floor(videoLenth/1.))%60];
    }else{
        strtotol = [NSString stringWithFormat:@"%02li:%02li:%02li",lround(floor(videoLenth/3600.)),lround(floor(videoLenth/60.)),lround(floor(videoLenth/1.))%60];
    }
    _totolTimeLabel.text = strtotol;
}

#pragma mark - NSNotificationCenter
-(void)appDidEnterBackground:(NSNotification *)notif{
    if (self.status == CPPlayerStatusPlaying) {
        [self pause];
    }
}

-(void)appDidEnterPlayGround:(NSNotification *)notif{
    if (!_isUserPause && self.status == CPPlayerStatePause) {
        [self play];
    }
}
-(void)playerItemPlayToEnd:(NSNotification *)notif{
    [self stop];
}
-(void)playerItemPlaybackStalled:(NSNotification *)notif{
    
}

-(void)creatUI:(UIView *)showView{
    [showView addSubview:self.navView];
    [self.navView addSubview:self.currentTimeLabel];
    [self.navView addSubview:self.totolTimeLabel];
    [self.navView addSubview:self.pauseBtn];
    //    [self.navView addSubview:self.rerunBtn];
    [self.navView addSubview:self.playSlider];
    [self.navView addSubview:self.videoProgressView];
}
#pragma mark - 播放状态为暂停
-(void)pause{
    [self.player pause];
    self.pauseBtn.selected = YES;
    self.status = CPPlayerStatePause;
}
#pragma mark - 播放状态为播放
-(void)play{
    [self.player play];
    self.pauseBtn.selected = NO;
    self.status = CPPlayerStatusPlaying;
}
#pragma mark - 播放状态为停止播放
-(void)stop{
    //    self.isPauseByUser = YES;
    //    self.loadedProgress = 0;
    self.duration = 0;
    self.current  = 0;
    self.status = CPPlayerStatusStop;
    [self.player pause];
    self.pauseBtn.selected = YES;
    //    [self releasePlayer];
}
-(void)resumeOrPause:(UIButton *)sender{
    if (self.status == CPPlayerStatusStop) {
        return ;
    }
    sender.selected = !sender.selected;
    self.isUserPause = sender.selected;
    
    if (sender.selected) {
        [self pause];
    }
    else{
        [self play];
    }
}
-(void)playSliderChange:(UISlider *)sender{
    [self updateCurrentTime:sender.value];
}
-(void)playSliderChangeEnd:(UISlider *)sender{
    [self updateCurrentTime:sender.value];
    [self seekToTime:sender.value];
}
-(void)seekToTime:(CGFloat)seconds{
    seconds = MAX(0, seconds);
    seconds = MIN(seconds, self.duration);
    [self pause];
    [self.player seekToTime:CMTimeMakeWithSeconds(seconds, NSEC_PER_SEC) completionHandler:^(BOOL finished) {
        if (!self.isUserPause) {
            [self play];
        }
        if (!self.currentPlayerItem.isPlaybackLikelyToKeepUp) {
            [MBProgressHUD showHUDAddedTo:self animated:YES];
           [self bufferingSomeSecond];
        }
        
    }];
}
#pragma mark - CPLoaderURLConectionDelegate
//网络中断：-1005
//无网络连接：-1009
//请求超时：-1001
//服务器内部错误：-1004
//找不到服务器：-1003
- (void)didFailLoadingWithTask:(CPLoaderURLConection *)task WithError:(NSInteger)errorCode
{
    self.status = CPPlayerStatePause;
    self.pauseBtn.selected = YES;
    NSString *str = nil;
    switch (errorCode) {
        case -1001:
            str = @"请求超时";
            break;
        case -1003:
        case -1004:
            str = @"服务器错误";
            break;
        case -1005:
            str = @"网络中断";
            break;
        case -1009:
            str = @"无网络连接";
            break;
        default:
            str = [NSString stringWithFormat:@"%@", @"(_errorCode)"];
            break;
    }
}
-(void)didFinishLoadingWithTask:(CPVideoRequestTask *)task{
    _isFinishLoad = task.isFinishLoad;
}

#pragma mark 懒加载
-(void)setLoadedProgress:(CGFloat)loadedProgress{
    if (_loadedProgress == loadedProgress) {
        return ;
    }
    _loadedProgress = loadedProgress;
}
-(void)setStatus:(CPPlayerStatus)status
{
    if (status != CPPlayerStatusBuffering) {
        [MBProgressHUD hideAllHUDsForView:self animated:YES];
    }
    if (_status == status) {
        return ;
    }
    _status = status;
}
-(UIView *)navView{
    if (!_navView) {
        _navView = [[UIView alloc]initWithFrame:CGRectMake(0, 20, kScreenWidth, 44)];
        _navView.backgroundColor = [UIColor colorWithHex:0x000000 alpha:0.5];
        //        _navBar.frame = CGRectMake(0, 0, kScreenWidth, 44);
    }
    return _navView;
}
#pragma mark当前时间
-(UILabel *)currentTimeLabel{
    if (!_currentTimeLabel) {
        _currentTimeLabel = [[UILabel alloc] init];
        _currentTimeLabel.textColor = [UIColor colorWithHex:0xffffff alpha:1.0];
        _currentTimeLabel.font = [UIFont systemFontOfSize:10.0];
        _currentTimeLabel.frame = CGRectMake(30, 0, 52, 44);
        _currentTimeLabel.textAlignment = NSTextAlignmentRight;
    }
    return _currentTimeLabel;
}
#pragma mark 总时间
-(UILabel *)totolTimeLabel{
    if (!_totolTimeLabel) {
        _totolTimeLabel = [[UILabel alloc] init];
        _totolTimeLabel.textColor = [UIColor colorWithHex:0xffffff alpha:1.0];
        _totolTimeLabel.font = [UIFont systemFontOfSize:10.0];
        _totolTimeLabel.frame = CGRectMake(kScreenWidth-52, 0, 52, 44);
        _totolTimeLabel.textAlignment = NSTextAlignmentLeft;
    }
    return _totolTimeLabel;
}
#pragma mark 进度条
-(UIProgressView *)videoProgressView{
    if (!_videoProgressView) {
        _videoProgressView = [[UIProgressView alloc] init];
        _videoProgressView.progressTintColor = [UIColor colorWithHex:0xffffff alpha:1.0];  //填充部分颜色
        _videoProgressView.trackTintColor = [UIColor colorWithHex:0xffffff alpha:0.18];   // 未填充部分颜色
        _videoProgressView.frame = CGRectMake(62+30, 21, kScreenWidth-124-44+15, 20);
        _videoProgressView.layer.cornerRadius = 1.5;
        _videoProgressView.layer.masksToBounds = YES;
        CGAffineTransform transform = CGAffineTransformMakeScale(1.0, 1.5);
        _videoProgressView.transform = transform;
    }
    return _videoProgressView;
}
#pragma mark 暂停按钮
-(UIButton *)pauseBtn{
    if (!_pauseBtn) {
        _pauseBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _pauseBtn.frame = CGRectMake(0, 0, 44, 44);
        [_pauseBtn addTarget:self action:@selector(resumeOrPause:) forControlEvents:UIControlEventTouchUpInside];
        [_pauseBtn setImage:[UIImage imageNamed:@"icon_pause"] forState:UIControlStateNormal];
//        [_pauseBtn setImage:[UIImage imageNamed:@"icon_pause_hl"] forState:UIControlStateHighlighted];
        [_pauseBtn setImage:[UIImage imageNamed:@"icon_play"] forState:UIControlStateSelected];
//        [_pauseBtn setImage:[UIImage imageNamed:@"icon_play_hl"] forState:UIControlStateHighlighted];
    }
    return _pauseBtn;
}

#pragma mark 滑竿
-(UISlider *)playSlider{
    if (!_playSlider) {
        _playSlider = [[UISlider alloc] init];
        _playSlider.frame = CGRectMake(62+30, 0, kScreenWidth-124-44+15, 44);
        [_playSlider setThumbImage:[UIImage imageNamed:@"icon_progress"] forState:UIControlStateNormal];
        _playSlider.minimumTrackTintColor = [UIColor clearColor];
        _playSlider.maximumTrackTintColor = [UIColor clearColor];
        [_playSlider addTarget:self action:@selector(playSliderChange:) forControlEvents:UIControlEventValueChanged]; //拖动滑竿更新时间
        [_playSlider addTarget:self action:@selector(playSliderChangeEnd:) forControlEvents:UIControlEventTouchUpInside];  //松手,滑块拖动停止
        [_playSlider addTarget:self action:@selector(playSliderChangeEnd:) forControlEvents:UIControlEventTouchUpOutside];
        [_playSlider addTarget:self action:@selector(playSliderChangeEnd:) forControlEvents:UIControlEventTouchCancel];
    }
    return _playSlider;
}
#pragma mark 重播按钮
-(UIButton *)rerunBtn{
    if (!_rerunBtn) {
        _rerunBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _rerunBtn.frame = CGRectMake(100, 400, 60, 30);
        [_rerunBtn setTitle:@"重播" forState:UIControlStateNormal];
    }
    return _rerunBtn;
}
@end
