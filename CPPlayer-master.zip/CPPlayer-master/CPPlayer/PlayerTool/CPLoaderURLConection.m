//
//  CPLoaderURLConection.m
//  CPPlayer
//
//  Created by  on 16/3/21.
//  Copyright © 2016年 . All rights reserved.
//  AVPlayerItem的URLConection代理,AVPlaterItem从这里面读取数据

#import "CPLoaderURLConection.h"
#import <MobileCoreServices/MobileCoreServices.h>

@interface CPLoaderURLConection ()<CPVideoRequestTaskDelegate>{
    }
@property (nonatomic,strong)NSMutableArray *pendingRequests;
@end

@implementation CPLoaderURLConection
- (instancetype)init
{
    self = [super init];
    if (self) {
        NSString *document = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).lastObject;
        _tempPath =  [document stringByAppendingPathComponent:@"temp.mp4"];
    }
    return self;
}

-(BOOL)resourceLoader:(AVAssetResourceLoader *)resourceLoader shouldWaitForLoadingOfRequestedResource:(AVAssetResourceLoadingRequest *)loadingRequest{
    [self.pendingRequests addObject:loadingRequest];
    [self dealWithLoadingRequest:loadingRequest];
    return YES;
}
-(void)resourceLoader:(AVAssetResourceLoader *)resourceLoader didCancelLoadingRequest:(AVAssetResourceLoadingRequest *)loadingRequest
{
    [self.pendingRequests removeObject:loadingRequest];
}
-(void)dealWithLoadingRequest:(AVAssetResourceLoadingRequest *)loadingRequest{
    NSURL *interceptedURL = [loadingRequest.request URL];
    NSRange range = NSMakeRange((NSUInteger)loadingRequest.dataRequest.currentOffset, NSUIntegerMax);
    if (self.task.downLoadingOffset > 0) {
        [self processPendingRequests];
    }
    if (!self.task) {
        self.task = [[CPVideoRequestTask alloc]init];
        self.task.delegate = self;
        self.task.movePath = self.videoPath;
        self.task.tempPath = self.tempPath;
        [self.task setUrl:interceptedURL offset:0];
    }
    else{
        // 如果新的rang的起始位置比当前缓存的位置还大300k，则重新按照range请求数据
        if (self.task.offset + self.task.downLoadingOffset + 300 * 1024 < range.location ||//如果往回拖也重新请求
            range.location < self.task.offset) {
            [self.task setUrl:interceptedURL offset:range.location];
        }
    }
}
- (void)fillInContentInformation:(AVAssetResourceLoadingContentInformationRequest *)contentInformationRequest{
    NSString *mimeType = self.task.mimeType;
    CFStringRef contentType = UTTypeCreatePreferredIdentifierForTag(kUTTagClassMIMEType, (__bridge CFStringRef)(mimeType), NULL);
    contentInformationRequest.byteRangeAccessSupported = YES;
    contentInformationRequest.contentType = CFBridgingRelease(contentType);
    contentInformationRequest.contentLength = self.task.videoLength;
}
- (void)processPendingRequests{
    NSMutableArray *requestsCompleted = [NSMutableArray array];//请求完成的数组
    //每次下载一块数据都是一次请求,把这些请求放到数组,遍历数组
    for (AVAssetResourceLoadingRequest *loadingRequest in self.pendingRequests) {
        [self fillInContentInformation:loadingRequest.contentInformationRequest];//对每次请求加上度,文件类型等信息
        BOOL didRespondCompletely = [self respondWithDataForRequestForRequest:loadingRequest.dataRequest];//判断此次请求的数据是否处理完成
        if(didRespondCompletely){
            [requestsCompleted addObject:loadingRequest];
            [loadingRequest finishLoading];
        }
    }
    [self.pendingRequests removeObjectsInArray:requestsCompleted];//将请求完成的从数组中移除
}
-(BOOL)respondWithDataForRequestForRequest:(AVAssetResourceLoadingDataRequest *)dataRequest{
    long long startOffset = dataRequest.requestedOffset;
    //起始偏移位置
    if (dataRequest.currentOffset != 0) {
        startOffset = dataRequest.currentOffset;
    }
    if ((self.task.offset + self.task.downLoadingOffset) < startOffset) {
        //当前的请求的起始位置已在缓存范围内
        return NO;
    }
    if (startOffset < self.task.offset) {
        return NO;
    }
    NSData *fileData = [NSData dataWithContentsOfURL:[NSURL fileURLWithPath:_tempPath] options:NSDataReadingMappedIfSafe error:nil];
    NSUInteger unreadBytes = self.task.downLoadingOffset - ((NSInteger)startOffset - self.task.offset);//在当前请求中删除上一个请求的下载数据
    NSUInteger numberOfbuesToRepondWith = MIN(dataRequest.requestedLength, unreadBytes);
    [dataRequest respondWithData:[fileData subdataWithRange:NSMakeRange((NSUInteger)startOffset - self.task.offset, numberOfbuesToRepondWith)]];
    long long endOffset = startOffset + dataRequest.requestedLength;
    BOOL didRepondFully = (self.task.offset + self.task.downLoadingOffset) >= endOffset;
    return didRepondFully;
}
-(NSURL *)getSchemeViderURL:(NSURL *)url{
    NSURLComponents *components = [[NSURLComponents alloc] initWithURL:url resolvingAgainstBaseURL:NO];
    components.scheme = @"streaming";
    return [components URL];
}
-(NSMutableArray *)pendingRequests{
    if (!_pendingRequests) {
        _pendingRequests = [NSMutableArray array];
    }
    return _pendingRequests;
}
#pragma mark - CPVideoRequestTaskDelegate
- (void)didReceiveVideoDataWithTask:(CPVideoRequestTask *)task
{
    [self processPendingRequests];
    
}
-(void)didFailLoadingWithTask:(CPVideoRequestTask *)task WithError:(NSInteger)errorCode{
    if ([self.delegate respondsToSelector:@selector(didFailLoadingWithTask:WithError:)]) {
        [self.delegate didFailLoadingWithTask:task WithError:errorCode];
    }
}
-(void)didFinishLoadingWithTask:(CPVideoRequestTask *)task{
    if ([self.delegate respondsToSelector:@selector(didFinishLoadingWithTask:)]) {
        [self.delegate didFinishLoadingWithTask:task];
    }
}
@end
